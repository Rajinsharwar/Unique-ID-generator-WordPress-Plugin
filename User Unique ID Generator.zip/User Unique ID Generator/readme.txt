Unique Customer ID Generator & Displayer

== Description ==
This plugin generates an unique customert ID for every registered user, and displays them while they are logged in. You can choose to display the ID any where and everywhere suing either a simple shortcode, or a simple function.



** How to use it on posts or pages?

Use the shortcode `[customer-id]`


** How can I use it in my theme?

You can call the function get_current_usser_id()
To display it, you can paste the below snippet:
<?php print get_current_user_id(); ?>

